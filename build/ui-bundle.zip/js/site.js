"use strict";

;

(function () {
  'use strict'; // navigation

  var nav = document.querySelector('.js-nav');
  var navLists = nav.querySelectorAll('.js-nav-list');
  var navLink = nav.querySelectorAll('.js-nav-link');
  var navListsHeights = [];
  var navListItems;
  var navListItemHeight; // calculate list height and set height on initial list

  for (var i = 0; i < navLists.length; i++) {
    // get all list items and reset height
    navListItems = navLists[i].querySelectorAll('li');
    navListItemHeight = 0; // get height of all list items

    for (var x = 0; x < navListItems.length; x++) {
      navListItemHeight += navListItems[x].offsetHeight;
      navListsHeights[i] = navListItemHeight;
    } // set initial active list height


    if (navLists[i].classList.contains('active')) {
      navLists[i].style.transition = 'none';
      navLists[i].style.maxHeight = "".concat(navListsHeights[i], "px");
    }
  } // setup toggle events


  for (var _i = 0; _i < navLink.length; _i++) {
    navLink[_i].addEventListener('click', function (e) {
      return toggleNav(e, navLists, navListsHeights);
    });

    navLink[_i].addEventListener('touchend', function (e) {
      return toggleNav(e, navLists, navListsHeights);
    });
  }

  var showNav = function showNav() {
    var nav = document.querySelector('.js-nav .nav-list');
    if (!nav.classList.contains('loaded')) nav.classList.add('loaded');
  };

  var toggleNav = function toggleNav(e, navLists, navListsHeights, thisProduct, thisVersion) {
    var noTransition = false;
    var thisTarget = e.target;
    var thisList;
    var thisIndex;
    var collapse; // when navigating on page load

    if (e.type === 'DOMContentLoaded') {
      // check if there's a pinned version
      var loadVersion = thisVersion || localStorage.getItem("ms-docs-".concat(thisProduct));

      if (loadVersion) {
        thisList = nav.querySelector("[data-product=\"".concat(thisProduct, "\"][data-version=\"").concat(loadVersion, "\"]"));
      } else {
        thisList = nav.querySelector(".js-nav-list[data-product=\"".concat(thisProduct, "\"]"));
      }

      noTransition = true;
    } else if (thisTarget.classList.contains('js-nav-link')) {
      // if navigating via sidebar
      var thisWrapper = thisTarget.parentElement;
      var thisNavLi = thisWrapper.parentElement;
      thisList = thisNavLi.querySelector('[data-pinned]') || thisWrapper.nextElementSibling;
      collapse = thisNavLi.classList.contains('active') || false;
      analytics.track('Toggled Nav', {
        url: thisTarget.innerText
      });
    } else {
      // if navigation via version select
      thisList = nav.querySelector("[data-product=\"".concat(thisProduct, "\"][data-version=\"").concat(thisVersion, "\"]")); // used for disabling transition during version change

      noTransition = true;
    }

    for (var _i2 = 0; _i2 < navLists.length; _i2++) {
      // if transition disabled on load, re-enable
      if (noTransition) {
        navLists[_i2].classList.add('transition-opacity-only');
      } else if (navLists[_i2].classList.contains('transition-opacity-only')) {
        navLists[_i2].classList.remove('transition-opacity-only');
      } // make other elements inactive


      navLists[_i2].parentNode.classList.remove('active');

      navLists[_i2].style.maxHeight = null;
      navLists[_i2].style.opacity = '0'; // check if list matches active target

      if (navLists[_i2] === thisList) {
        thisIndex = _i2;
      }
    } // close any open popovers


    closePopovers(); // if there's no list, stop here

    if (!thisList) return; // make current element active if not collapsing

    if (!collapse) {
      thisList.style.maxHeight = "".concat(navListsHeights[thisIndex], "px");
      thisList.style.opacity = '1';
      thisList.parentNode.classList.add('active');
      if (noTransition) thisList.classList.add('transition-opacity-only');
    } // finish load transition


    if (e.type === 'DOMContentLoaded') {
      showNav();
      scrollToActive(thisList);
    }
  }; // this scrolls the navbar to the current page…
  // really this doesn't work great b/c the nav should not reload when the page changes (singe-page)


  var scrollToActive = function scrollToActive(thisList) {
    var activeLinks = thisList.querySelectorAll('.nav-link.active');

    for (var _i3 = 0; _i3 < activeLinks.length; _i3++) {
      var _thisList = activeLinks[_i3].parentNode;

      while (_thisList.style.opacity === '1') {
        _thisList = _thisList.parentNode;
      }

      document.querySelector('.js-nav').scrollTo({
        behavior: 'smooth',
        top: _thisList.offsetTop - window.innerHeight / 2 + 65 // scroll to center; 65 is the header height

      });
      break;
    }
  }; // version popovers
  // tippy plugin https://atomiks.github.io/tippyjs/


  var versionsTrigger = document.querySelectorAll('[data-trigger="versions"]');
  var versionsPopover = document.querySelectorAll('[data-popover="versions"]');

  var setPin = function setPin(thisProduct, thisTrigger, thisVersion) {
    var savedVersion = localStorage.getItem("ms-docs-".concat(thisProduct));

    if (savedVersion) {
      thisTrigger.querySelector('.js-versions-text').textContent = savedVersion;

      for (var _i4 = 0; _i4 < navLists.length; _i4++) {
        var listProduct = navLists[_i4].getAttribute('data-product');

        var listVersion = navLists[_i4].getAttribute('data-version');

        if (thisProduct === listProduct && savedVersion === listVersion) {
          navLists[_i4].setAttribute('data-pinned', true);
        }
      }
    }

    analytics.track('Version Pinned', {
      product: thisProduct,
      version: thisVersion
    });
  };

  for (var _i5 = 0; _i5 < versionsTrigger.length; _i5++) {
    tippy(versionsTrigger[_i5], {
      duration: [0, 150],
      flip: false,
      html: versionsPopover[_i5],
      offset: '-40, 5',
      onHide: function onHide(instance) {
        this.classList.add('hide');
        this.classList.remove('shown');
        unbindEvents(this);
      },
      onShow: function onShow(instance) {
        closePopovers(instance);
        this.classList.remove('hide');
        bindEvents(this);
      },
      onShown: function onShown(instance) {
        this.classList.add('shown');
      },
      placement: 'bottom',
      theme: 'popover-versions',
      trigger: 'click',
      zIndex: 14 // same as z-nav-mobile

    }); // if a version has been pinned

    setPin(versionsTrigger[_i5].getAttribute('data-trigger-product'), versionsTrigger[_i5]);
  }

  var closePopovers = function closePopovers(instance) {
    var popper = document.querySelector('.tippy-popper');
    if (popper) popper._tippy.hide();
  }; // changing versions


  var changeVersion = function changeVersion(e) {
    var thisTippy = document.querySelector('.tippy-popper')._tippy;

    var thisTarget = e.target;
    var thisProduct = thisTarget.getAttribute('data-product');
    var thisVersion = thisTarget.getAttribute('data-version'); // save version

    localStorage.setItem("ms-docs-".concat(thisProduct), thisVersion); // update pins

    setPin(thisProduct, thisTippy.reference, thisVersion); // update nav

    toggleNav(e, navLists, navListsHeights, thisProduct, thisVersion); // close the popover

    thisTippy.hide();
    e.stopPropagation();
  };

  var bindEvents = function bindEvents(popover) {
    var versions = popover.querySelectorAll('.js-version');

    for (var _i6 = 0; _i6 < versions.length; _i6++) {
      versions[_i6].addEventListener('click', changeVersion);

      versions[_i6].addEventListener('touchend', changeVersion);
    }
  };

  var unbindEvents = function unbindEvents(popover) {
    var versions = popover.querySelectorAll('.js-version');

    for (var _i7 = 0; _i7 < versions.length; _i7++) {
      versions[_i7].removeEventListener('click', changeVersion);

      versions[_i7].removeEventListener('touchend', changeVersion);
    }
  }; // open current nav on load


  window.addEventListener('DOMContentLoaded', function (e) {
    var thisProduct = window.location.pathname.replace(/^\/([^/]*).*$/, '$1');

    if (thisProduct !== '') {
      toggleNav(e, navLists, navListsHeights, thisProduct);
    }

    showNav();
  });
})();
"use strict";

;

(function () {
  'use strict';

  var doc = document.querySelector('.doc');
  if (!doc) return;
  var sidebar = document.querySelector('.js-toc');
  var menu;
  var headings = find('.sect1 > h2[id]', doc);

  if (!headings.length) {
    if (sidebar) {
      sidebar.parentNode.removeChild(sidebar);
      document.querySelector('.main').classList.add('no-sidebar');
    }

    return;
  }

  var lastActiveFragment;
  var links = {};
  var list = headings.reduce(function (accum, heading) {
    var link = toArray(heading.childNodes).reduce(function (target, child) {
      if (child.nodeName !== 'A') target.appendChild(child.cloneNode(true));
      return target;
    }, document.createElement('a'));
    links[link.href = '#' + heading.id] = link;
    var listItem = document.createElement('li');
    listItem.appendChild(link);
    accum.appendChild(listItem);
    return accum;
  }, document.createElement('ol'));

  if (!(menu = sidebar && sidebar.querySelector('.toc-menu'))) {
    menu = document.createElement('div');
    menu.className = 'toc-menu';
  }

  menu.appendChild(list);
  if (sidebar) window.addEventListener('scroll', onScroll);
  var startOfContent = doc.querySelector('h1.page + *');

  if (startOfContent) {
    // generate list
    var options = headings.reduce(function (accum, heading) {
      var option = toArray(heading.childNodes).reduce(function (target, child) {
        if (child.nodeName !== 'A') target.appendChild(child.cloneNode(true));
        return target;
      }, document.createElement('option'));
      option.value = "#".concat(heading.id);
      accum.appendChild(option);
      return accum;
    }, document.createElement('select'));
    var selectWrap = document.createElement('div');
    selectWrap.classList.add('select-wrapper');
    selectWrap.appendChild(options); // create jump to label

    var jumpTo = document.createElement('option');
    jumpTo.innerHTML = 'Jump to…';
    jumpTo.setAttribute('disabled', true);
    options.insertBefore(jumpTo, options.firstChild);
    options.className = 'toc toc-embedded select'; // jump on change

    options.addEventListener('change', function (e) {
      var thisOptions = e.currentTarget.options;
      var thisValue = thisOptions[thisOptions.selectedIndex].value;
      window.location.hash = "".concat(thisValue);
    }); // add to page

    doc.insertBefore(selectWrap, startOfContent);
  }

  function onScroll() {
    // NOTE equivalent to: doc.parentNode.getBoundingClientRect().top + window.pageYOffset
    var targetPosition = doc.parentNode.offsetTop;
    var activeFragment;
    headings.some(function (heading) {
      if (heading.getBoundingClientRect().top < targetPosition) {
        activeFragment = '#' + heading.id;
      } else {
        return true;
      }
    });

    if (activeFragment) {
      if (lastActiveFragment) {
        links[lastActiveFragment].classList.remove('active');
      }

      var activeLink = links[activeFragment];
      activeLink.classList.add('active');

      if (menu.scrollHeight > menu.offsetHeight) {
        menu.scrollTop = Math.max(0, activeLink.offsetTop + activeLink.offsetHeight - menu.offsetHeight);
      }

      lastActiveFragment = activeFragment;
    } else if (lastActiveFragment) {
      links[lastActiveFragment].classList.remove('active');
      lastActiveFragment = undefined;
    }
  }

  function find(selector, from) {
    return toArray((from || document).querySelectorAll(selector));
  }

  function toArray(collection) {
    return [].slice.call(collection);
  }
})();
"use strict";

;

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    var body = document.body;
    var navToggle = body.querySelectorAll('.js-nav-toggle');
    var nav = body.querySelector('.js-nav');
    var backdrop = document.querySelector('.modal-backdrop');

    var openNav = function openNav(e) {
      clickThru(e);
      nav.classList.add('active');
      body.classList.add('no-scroll', 'mobile');
      backdrop.classList.add('show', 'mobile');
    };

    var closeNav = function closeNav() {
      nav.classList.remove('active');
      body.classList.remove('no-scroll', 'mobile');
      backdrop.classList.remove('show', 'mobile');
    };

    var clickThru = function clickThru(e) {
      e.stopPropagation(); // don't prevent link behavior if this is a link

      if (!e.target.href) e.preventDefault();
    }; // navtoggle listeners


    for (var i = 0; i < navToggle.length; i++) {
      navToggle[i].addEventListener('click', openNav);
      navToggle[i].addEventListener('touchend', openNav);
    } // body listener


    body.addEventListener('click', closeNav);
    body.addEventListener('touchend', closeNav); // prevent clicks on nav from closing

    nav.addEventListener('click', clickThru);
    nav.addEventListener('touchend', clickThru);
  });
})();
"use strict";

;

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    // coveo setup
    var body = document.body;
    var root = body.querySelector('.js-coveo');
    Coveo.SearchEndpoint.endpoints['default'] = new Coveo.SearchEndpoint({
      restUri: 'https://platform.cloud.coveo.com/rest/search',
      accessToken: 'xx3ba020b0-d9b5-4339-bc0e-92fe79a681e7'
    });
    root.addEventListener('buildingQuery', function (e) {
      e.detail.queryBuilder.pipeline = 'doc-query-pipeline';
    }); // modal setup

    var backdrop = body.querySelector('.modal-backdrop');
    var nav = body.querySelector('.js-nav'); // show/hide coveo search

    var searchTrigger = body.querySelector('.js-search-trigger');
    var searchUI = body.querySelector('.js-search-ui');
    var searchClose = body.querySelector('.js-search-close');

    var showCoveo = function showCoveo() {
      backdrop.classList.add('show');
      backdrop.classList.remove('mobile');
      body.classList.add('no-scroll');
      body.classList.remove('mobile');
      searchUI.classList.add('show');
      nav.classList.remove('active');
      body.querySelector('.CoveoSearchbox input').focus(); // hide any popovers

      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = document.querySelectorAll('.tippy-popper')[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var popper = _step.value;
          var instance = popper._tippy;

          if (instance.state.visible) {
            instance.hide();
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return != null) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      analytics.track('Clicked Open Search');
    };

    var hideCoveo = function hideCoveo() {
      backdrop.classList.remove('show');
      body.classList.remove('no-scroll');
      searchUI.classList.remove('show');
    };

    var clickThru = function clickThru(e) {
      return e.stopPropagation();
    };

    searchTrigger.addEventListener('click', showCoveo);
    searchTrigger.addEventListener('touchend', showCoveo);
    body.addEventListener('click', hideCoveo);
    body.addEventListener('touchend', hideCoveo);
    searchClose.addEventListener('click', hideCoveo);
    searchClose.addEventListener('touchend', hideCoveo);
    document.addEventListener('keydown', function (e) {
      if (e.keyCode === 27) hideCoveo();
    }); // prevent clicks on nav from closing

    root.addEventListener('click', clickThru);
    root.addEventListener('touchend', clickThru); // init

    Coveo.init(root);
  });
})();
"use strict";

;

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    var nestedNavs = document.querySelectorAll('.js-nav-nested'); // find and expand list if there's a nested active link

    for (var i = 0; i < nestedNavs.length; i++) {
      var nestedLinks = nestedNavs[i].nextElementSibling.querySelectorAll('.nav-link');

      for (var _i = 0; _i < nestedLinks.length; _i++) {
        if (nestedLinks[_i].classList.contains('active')) {
          // get this active list & expand it
          var thisList = nestedLinks[_i];

          while (!thisList.classList.contains('nav-list')) {
            thisList = thisList.parentNode;
          }

          thisList.previousElementSibling.classList.add('expanded'); // check if this is a nested, nested list

          var thisListParent = thisList.parentNode.parentNode;

          if (!thisListParent.classList.contains('parent')) {
            thisListParent.previousElementSibling.classList.add('expanded');
          } // check if this is a nested, nested, nested list


          var thisListParentParent = thisListParent.parentNode.parentNode;

          if (!thisListParentParent.classList.contains('parent')) {
            thisListParentParent.previousElementSibling.classList.add('expanded');
          }
        }
      }
    }
  });
})();
"use strict";

;

(function () {
  'use strict'; // track not helpful

  var trackNotHelpful = function trackNotHelpful() {
    analytics.track('Clicked Helpful No', {
      title: document.title,
      url: window.location.href
    });
  }; // open jira dialog


  window.ATL_JQ_PAGE_PROPS = {
    'triggerFunction': function triggerFunction(showCollectorDialog) {
      document.querySelector('.js-jira').addEventListener('click', function (e) {
        e.preventDefault();
        showCollectorDialog();
        trackNotHelpful();
      });
      document.querySelector('.js-jira').addEventListener('touchend', function (e) {
        e.preventDefault();
        showCollectorDialog();
        trackNotHelpful();
      });
    },
    fieldValues: {
      description: 'URL: ' + window.location.href
    } // saying thanks

  };
  var thanksSection = document.querySelector('.js-thanks-section');
  var thanksTrigger = thanksSection.querySelector('.js-thanks');

  var sayThanks = function sayThanks() {
    thanksSection.classList.add('flip');
    analytics.track('Clicked Helpful Yes', {
      title: document.title,
      url: window.location.href
    });
  };

  document.addEventListener('DOMContentLoaded', function () {
    thanksTrigger.addEventListener('click', sayThanks);
    thanksTrigger.addEventListener('touchend', sayThanks);
  });
})();
"use strict";

;

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    var gitHubLinks = document.querySelectorAll('.js-github');

    var trackGitHub = function trackGitHub() {
      analytics.track('Clicked GitHub Link', {
        url: window.location.href
      });
    };

    for (var i = 0; i < gitHubLinks.length; i++) {
      gitHubLinks[i].addEventListener('click', trackGitHub);
      gitHubLinks[i].addEventListener('touchend', trackGitHub);
    }
  });
})();