'use strict'

module.exports = (str, suffix) => str.endsWith(suffix)
