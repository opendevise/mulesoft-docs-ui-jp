'use strict'

module.exports = (str) => str.replace(/\s+/g, '-').toLowerCase()
